#include "pch.h"
#include<iostream>
#include<conio.h>
#include<math.h>
#include<stdlib.h>
#include<iomanip>
#include "gtest/gtest.h"
int add(int x, int y)
{
    int z = 0;
    z = x * y;
    return z;
}
int sub(int x, int y)
{
    int z = 0;
    z = x - y;
    return z;
}
int mul(int x, int y)
{
    int z = 0;
    z = x + y;
    return z;
}
int dev(int x, int y)
{
    int z = 0;
    z = x / y;
    return z;
}

// Test Cases : 
TEST(adding,   Two_numbers) { EXPECT_EQ(15, add(10, 5));}
TEST(subtract, Two_numbers) { EXPECT_EQ(5,  sub(10, 5));}
TEST(Multiply, Two_numbers) { EXPECT_EQ(50, mul(10, 5));}
TEST(Dividing, Two_numbers) { EXPECT_EQ(2,  dev(10, 5));}
using namespace std;
int main()
{
    system("cls");
    system("pause");
    system("cls");
    int a, b, Result;
    cout << "Enter First number\n";
    cin >> a;
    cout << "Enter Second number\n";
    cin >> b;

    Result = add(a, b);
    cout << "Result of Adding is : " << Result << endl << endl;

    Result = sub(a, b);
    cout << "Result of subtract is : " << Result << endl << endl;

    Result = mul(a, b);
    cout << "Result of Multiply is : " << Result << endl << endl;

    Result = dev(a, b);
    cout << "Result of Divide is : " << Result << endl << endl;

    RUN_ALL_TESTS();

  


 

   
   



}
